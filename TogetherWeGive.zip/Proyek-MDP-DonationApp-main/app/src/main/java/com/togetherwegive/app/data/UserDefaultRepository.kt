package com.togetherwegive.app.data

class UserDefaultRepository {
}