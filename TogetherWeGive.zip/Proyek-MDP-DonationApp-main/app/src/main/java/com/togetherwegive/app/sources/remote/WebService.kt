package com.togetherwegive.app.sources.remote

interface WebService {
}