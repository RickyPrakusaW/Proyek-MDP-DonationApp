package com.togetherwegive.app.sources

class User {

}