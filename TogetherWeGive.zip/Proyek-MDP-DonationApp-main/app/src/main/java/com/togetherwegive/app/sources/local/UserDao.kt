package com.togetherwegive.app.sources.local

import androidx.room.Dao

@Dao
interface UserDao {

}